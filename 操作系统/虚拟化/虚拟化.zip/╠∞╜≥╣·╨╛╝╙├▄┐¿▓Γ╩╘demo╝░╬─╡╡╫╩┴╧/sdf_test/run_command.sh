#!/bin/sh
export LD_LIBRARY_PATH=./
ln -s ../LIB/libsdf_crypto.so.* libsdf_crypto.so

#ldconfig
