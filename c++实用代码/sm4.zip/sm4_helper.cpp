#include "sm4_helper.h"
#include <string>
#include <string.h>
#include "sm4.h"

namespace utils
{
stdex::string Sm4Helper::sm4_ecb_encode(const unsigned char* data,unsigned int len)
{
	sm4_context ctx;
	unsigned char key[16] = {0x01,0x23,0x45,0x67,0x89,0xab,0xcd,0xef,0xfe,0xdc,0xba,0x98,0x76,0x54,0x32,0x10};
	unsigned int _data_len;
	if(len==0)
		return "";
	_data_len = (len-1)/16*16+16;

	std::string str_data(_data_len,0);
	stdex::string str_result(_data_len,0);
	memcpy((unsigned char*)str_data.c_str(),data,len);

	sm4_setkey_enc(&ctx,key);
	unsigned char* p = (unsigned char*)str_result.c_str();
	sm4_crypt_ecb(&ctx,1,_data_len,(unsigned char*)str_data.c_str(),p);

	return str_result;
}

stdex::string Sm4Helper::sm4_ecb_decode(const unsigned char* data,unsigned int len)
{
	sm4_context ctx;
	unsigned char key[16] = {0x01,0x23,0x45,0x67,0x89,0xab,0xcd,0xef,0xfe,0xdc,0xba,0x98,0x76,0x54,0x32,0x10};
	unsigned int _data_len = len;
	if(len%16 != 0)
		return "";

	std::string str_data(_data_len,0);
	stdex::string str_result(_data_len,0);
	memcpy((unsigned char*)str_data.c_str(),data,len);

	sm4_setkey_dec(&ctx,key);
	unsigned char* p = (unsigned char*)str_result.c_str();
	sm4_crypt_ecb(&ctx,0,_data_len,(unsigned char*)str_data.c_str(),p);

	return str_result;
}
}

