#ifndef _SM4_HELPER_H_
#define _SM4_HELPER_H_
#include <string>
#include "../../corelib.utils.h"
#include <utils/stlex/stlex.h>	

namespace utils
{
class CORELIB_UTILS_API Sm4Helper
{
public:
	static stdex::string sm4_ecb_encode(const unsigned char* data,unsigned int len);
	static stdex::string sm4_ecb_decode(const unsigned char* data,unsigned int len);

};
}




#endif