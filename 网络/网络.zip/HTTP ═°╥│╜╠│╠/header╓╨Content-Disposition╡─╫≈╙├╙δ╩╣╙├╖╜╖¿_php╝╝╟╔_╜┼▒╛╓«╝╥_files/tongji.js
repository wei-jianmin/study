﻿var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "//hm.baidu.com/hm.js?b88cfc1ccab788f0903cac38c894caa3";
  var s = document.getElementsByTagName("script")[0]; 
  s.parentNode.insertBefore(hm, s);
})();
document.write('<scr'+'ipt src="http://s73.cnzz.com/stat.php?id=1585378&web_id=1585378" language="JavaScript"></sc'+'ript>');

if("undefined" != typeof tougao){
switch(tougao)
{	
	//mdxy-dxy
	case "mdxy-dxy" :
	document.write('<scrip'+'t src="http://s25.cnzz.com/stat.php?id=5488963&web_id=5488963" language="JavaScript"></sc'+'ript>');
	break;	
	
	//jingxian
	case "jingxian" :
	document.write('<scrip'+'t src="http://s25.cnzz.com/stat.php?id=5488916&web_id=5488916" language="JavaScript"></sc'+'ript>');
	break;	

	//whsnow
	case "whsnow" :
	document.write('<scrip'+'t src="http://s25.cnzz.com/stat.php?id=5488901&web_id=5488901" language="JavaScript"></sc'+'ript>');
	break;	
	
	//sunjs bc
	case "hebedich" :	
	document.write('<scrip'+'t src="http://s4.cnzz.com/stat.php?id=5922891&web_id=5922891" language="JavaScript"></sc'+'ript>');
	break;	
	
	//shichen
	case "shichen2014" :	
	document.write('<scrip'+'t src="http://s11.cnzz.com/stat.php?id=5934082&web_id=5934082" language="JavaScript"></sc'+'ript>');
	break;
	
	//maran
	case "mrr" :	
	document.write('<scrip'+'t src="http://s11.cnzz.com/stat.php?id=1255898164&web_id=1255898164" language="JavaScript"></sc'+'ript>');
	break;
	
	//lijiao
	case "lijiao" :	
	document.write('<scrip'+'t src="http://s4.cnzz.com/stat.php?id=1255898178&web_id=1255898178" language="JavaScript"></sc'+'ript>');
	break;
	

	//liuqinghe bc
	case "lqh" :
	document.write('<scrip'+'t src="http://s4.cnzz.com/stat.php?id=1260050127&web_id=1260050127" language="JavaScript"></sc'+'ript>');
	break;
	
	//zhoudan bc
	case "daisy" :
	document.write('<scrip'+'t src="http://s11.cnzz.com/stat.php?id=1260050104&web_id=1260050104" language="JavaScript"></sc'+'ript>');
	break;

	//zhangxin bc
	case "zx" :
	document.write('<scrip'+'t src="http://s95.cnzz.com/stat.php?id=1260728942&web_id=1260728942" language="JavaScript"></sc'+'ript>');
	break;
	
	//mengwei bc
	case "mengwei" :
	document.write('<scrip'+'t src="http://s22.cnzz.com/stat.php?id=1266238153&web_id=1266238153" language="JavaScript"></sc'+'ript>');
	break;
	
	//zhangjunjian bc
	case "laozhang" :
	document.write('<scrip'+'t src="https://s19.cnzz.com/z_stat.php?id=1267982899&web_id=1267982899" language="JavaScript"></sc'+'ript>');
	break;
	
	//jingxian
	case "12" :	
	document.write('<scrip'+'t src="http://s25.cnzz.com/stat.php?id=5488916&web_id=5488916" language="JavaScript"></sc'+'ript>');
	break;	
	
	//pyg
	case "23" :
	document.write('<scrip'+'t src="http://s25.cnzz.com/stat.php?id=5488921&web_id=5488921" language="JavaScript"></sc'+'ript>');
	break;
	
	//zhangjunjian
	case "72" :
	document.write('<scrip'+'t src="https://s19.cnzz.com/z_stat.php?id=1267982899&web_id=1267982899" language="JavaScript"></sc'+'ript>');
	break;
	
	//lijihui
	case "70" :
	document.write('<scrip'+'t src="http://s19.cnzz.com/stat.php?id=1266239448&web_id=1266239448" language="JavaScript"></sc'+'ript>');
	break;

    //wangxia
	case "67" :
	document.write('<scrip'+'t src="http://s19.cnzz.com/stat.php?id=1262358339&web_id=1262358339" language="JavaScript"></sc'+'ript>');
	break;
	
	//shangjun
	case "66" :
	document.write('<scrip'+'t src="http://s95.cnzz.com/stat.php?id=1261400616&web_id=1261400616" language="JavaScript"></sc'+'ript>');
	break;

	//zhangxin
	case "63" :	
	document.write('<scrip'+'t src="http://s95.cnzz.com/stat.php?id=1260728942&web_id=1260728942" language="JavaScript"></sc'+'ript>');
	break;

	//zhoudan
	case "61" :	
	document.write('<scrip'+'t src="http://s11.cnzz.com/stat.php?id=1260050104&web_id=1260050104" language="JavaScript"></sc'+'ript>');
	break;

	//wuyue
	case "60" :	
	document.write('<scrip'+'t src="http://s4.cnzz.com/stat.php?id=1260419126&web_id=1260419126" language="JavaScript"></sc'+'ript>');
	break;
			
	//lijiao
	case "50" :	
	document.write('<scrip'+'t src="http://s4.cnzz.com/stat.php?id=1255898178&web_id=1255898178" language="JavaScript"></sc'+'ript>');
	break;
	
	//maran
	case "49" :	
	document.write('<scrip'+'t src="http://s11.cnzz.com/stat.php?id=1255898164&web_id=1255898164" language="JavaScript"></sc'+'ript>');
	break;
	
	//yunny
	case "47" :	
document.write('<scrip'+'t src="http://s11.cnzz.com/stat.php?id=1255898193&web_id=1255898193" language="JavaScript"></sc'+'ript>');
	break;

		//zhangyan
	case "39" :	
	document.write('<scrip'+'t src="http://v1.cnzz.com/stat.php?id=1253492952&web_id=1253492952" language="JavaScript"></sc'+'ript>');
	break;
	
	//chenxuejiao
	case "37" :	
	document.write('<scrip'+'t src="http://s5.cnzz.com/stat.php?id=1253237291&web_id=1253237291" language="JavaScript"></sc'+'ript>');
	break;
	
	//shichen
	case "36" :	
	document.write('<scrip'+'t src="http://s11.cnzz.com/stat.php?id=5934082&web_id=5934082" language="JavaScript"></sc'+'ript>');
	break;	
	
	//hexuemei
	case "35" :	
	document.write('<scrip'+'t src="http://s19.cnzz.com/stat.php?id=5922893&web_id=5922893" language="JavaScript"></sc'+'ript>');
	break;

	//sunjingsong
	case "34" :	
	document.write('<scrip'+'t src="http://s4.cnzz.com/stat.php?id=5922891&web_id=5922891" language="JavaScript"></sc'+'ript>');
	break;
	
	//huliuyue
	case "27" :
	document.write('<scrip'+'t src="http://s5.cnzz.com/stat.php?id=5835871&web_id=5835871" language="JavaScript"></sc'+'ript>');
	break;
	
	//whsnow
	case "21" :
	document.write('<scrip'+'t src="http://s25.cnzz.com/stat.php?id=5488901&web_id=5488901" language="JavaScript"></sc'+'ript>');
	break;	
	
	//xss
	case "10" :
	document.write('<scrip'+'t src="http://s25.cnzz.com/stat.php?id=5488783&web_id=5488783" language="JavaScript"></sc'+'ript>');
	break;	

	//xiaolong
	case "6" :
	document.write('<scrip'+'t src="http://s25.cnzz.com/stat.php?id=5488919&web_id=5488919" language="JavaScript"></sc'+'ript>');
	break;
	
	//mdxy-dxy
	case "1" :
	document.write('<scrip'+'t src="http://s25.cnzz.com/stat.php?id=5488963&web_id=5488963" language="JavaScript"></sc'+'ript>');
	break;	
  default :  
  //其它
        document.write('<scrip'+'t src="http://s25.cnzz.com/stat.php?id=5488951&web_id=5488951" language="JavaScript"></sc'+'ript>');
  break;
}
} 